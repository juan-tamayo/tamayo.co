const root = document.documentElement;
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const colorScheme = window.matchMedia('(prefers-color-scheme: dark)');
const themeButton = document.querySelector('#theme-toggle');
const motionButton = document.querySelector('#motion-toggle');
// Storage can be unavailable in privacy modes or when opened directly from disk.
try {
  const theme = localStorage.getItem('tamayo-theme');
  if (theme === 'dark' || theme === 'light') root.dataset.theme = theme;
} catch {}
function updateThemeLabel() {
  const dark = root.dataset.theme ? root.dataset.theme === 'dark' : colorScheme.matches;
  themeButton.setAttribute('aria-label', `Switch to ${dark ? 'light' : 'dark'} theme`);
}
themeButton.addEventListener('click', () => {
  const dark = root.dataset.theme ? root.dataset.theme === 'dark' : colorScheme.matches;
  root.dataset.theme = dark ? 'light' : 'dark';
  try { localStorage.setItem('tamayo-theme', root.dataset.theme); } catch {}
  updateThemeLabel();
});
colorScheme.addEventListener('change', updateThemeLabel);
updateThemeLabel();
function updateMotionButton() {
  const off = root.dataset.motion === 'off' || reducedMotion.matches;
  motionButton.querySelector('span').textContent = off ? 'Resume motion' : 'Pause motion';
  motionButton.setAttribute('aria-label', off ? 'Resume animations' : 'Pause animations');
  motionButton.querySelector('path').setAttribute('d', off ? 'm8 5 11 7-11 7Z' : 'M8 5v14M16 5v14');
  motionButton.setAttribute('aria-pressed', String(off));
  motionButton.disabled = reducedMotion.matches;
  motionButton.title = reducedMotion.matches ? 'Reduced motion follows your device preference' : off ? 'Resume animations' : 'Pause animations';
}
motionButton.addEventListener('click', () => {
  root.dataset.motion = root.dataset.motion === 'off' ? 'on' : 'off';
  updateMotionButton();
});
reducedMotion.addEventListener('change', updateMotionButton);
updateMotionButton();
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(element => {
    element.classList.add('ready');
    observer.observe(element);
  });
}
document.querySelector('#year').textContent = new Date().getFullYear();
// Keep the dock's current section in sync with ordinary scrolling.
if ('IntersectionObserver' in window) {
  const dockLinks = [...document.querySelectorAll('.dock-link')];
  const sectionObserver = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      dockLinks.forEach(link => {
        if (link.hash === `#${entry.target.id}`) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    }
  }, { rootMargin: '-15% 0px -55% 0px' });
  document.querySelectorAll('#work, #about, #contact, .hero').forEach(section => sectionObserver.observe(section));
}
// Stagger content without hiding it when scripting or motion is unavailable.
for (const group of ['.capabilities li', '.career-step', '.product-words span']) {
  document.querySelectorAll(group).forEach((element, index) => {
    element.style.setProperty('--i', index);
  });
}
